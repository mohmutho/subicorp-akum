<!-- Retur Pembelian -->
<div class="row">
  <div class="col-sm-12">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
          Retur Pembelian
        </h1>
        <ol class="breadcrumb">
          <li><a href="<?php echo site_url("dashboard")?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
          <li>Retur</li>
          <li class="active">Retur Pembelian</li>
        </ol><br>
        <?php echo $this->session->flashdata('notif')?>
    </section>

      <!-- Main content -->
    <section class="content">
        <!-- Info boxes -->
        <div class="box">
            <div class="box-header">
                
            </div>
            <div class="box-body form-horizontal">
            <?php echo form_open_multipart('retur/create_retur_pembelian/');?>
                <div class="autoSum">
                    <div class="form-group">
                        <label for="inputName" class="col-sm-2 control-label">Tanggal Transaksi</label>
                        <div class="col-sm-10">
                            <input type="text" name="tanggal" class="form-controls" id="datepicker"  placeholder="Tanggal Transaksi" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputName" class="col-sm-2 control-label">Nama Transaksi</label>
                        <div class="col-sm-10">
                            <select id="pilih_retur" name="pembelian_id" class="form-controls-select" onchange='changeValue(this.value)' required>
                            <option value="">Pilih</option>
                                <?php
                                    $jsArray = "var prdName = new Array();\n";
                                    foreach($main['sql']->result() as $obj){
                                        $pembelian_dari = $obj->pembelian_dari;
                                        $jumlah = $obj->jumlah;
                                        $nama_barang = $obj->nama_barang;
                                        $harga_barang = $obj->harga_barang;
                                        $total_harga = $obj->total_harga;
                                ?>
                                <option value="<?php echo $obj->id;?>">
                                    <?php echo $pembelian_dari;?>
                                </option>
                                <?php
                                    $jsArray .= "prdName['". $obj->id . "'] = {jumlah:'" . addslashes($jumlah) .
                                       "',nama_barang:'" . addslashes($nama_barang) . 
                                       "',total_harga:'" . addslashes($total_harga) . 
                                       "',pembelian_dari:'" . addslashes($pembelian_dari) . 
                                       "',harga_barang:'" . addslashes($harga_barang) . 
                                       "'};\n";
                                    }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputName" class="col-sm-2 control-label">Nama Barang</label>
                        <div class="col-sm-10">
                            <input readonly type="text" name="nama_barang" id="nama_barang" class="form-controls" placeholder="Nama Barang" required>
                            <!-- <input readonly type="hidden" name="total_harga" id="total_harga" class="form-controls" placeholder="Total Harga" required> -->
                            <input readonly type="hidden" name="pembelian_dari" id="pembelian_dari" class="form-controls" placeholder="Pembelian Dari" required>
                            <!-- <input readonly type="hidden" name="harga_barang" id="harga_barang" class="form-controls" placeholder="Harga Barang" required> -->
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputName" class="col-sm-2 control-label">Jumlah Barang</label>
                        <div class="col-sm-10">
                            <input readonly type="text" id="jumlah" name="jumlah_barang_stok" class="form-controls" placeholder="Jumlah Barang" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputName" class="col-sm-2 control-label">Harga Satuan Barang</label>
                        <div class="col-sm-10">
                            <input readonly type="text" name="harga_barang" id="harga_barang" class="form-controls" placeholder="Harga Satuan Barang" required>    
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputName" class="col-sm-2 control-label">Jumlah Barang Diretur</label>
                        <div class="col-sm-10">
                            <input type="text" name="jumlah_retur" class="form-controls" id="jumlah_retur" placeholder="Jumlah Barang Diretur" oninput="gantiValueJumlah()" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputName" class="col-sm-2 control-label">Total Harga Barang diretur</label>
                        <div class="col-sm-10">
                            <input readonly type="text" name="total_harga_retur" id="total_harga_retur" class="form-controls" placeholder="Total Harga Barang" required>    
                        </div>
                    </div>
                    <script type="text/javascript">    
                        <?php echo $jsArray; ?>  
                        function changeValue(x){  
                            document.getElementById('nama_barang').value = prdName[x].nama_barang;
                            document.getElementById('jumlah').value = prdName[x].jumlah;
                            document.getElementById('harga_barang').value = prdName[x].harga_barang;
                            document.getElementById('pembelian_dari').value = prdName[x].pembelian_dari;
                            // document.getElementById('total_harga').value = prdName[x].total_harga;
                            // var jumlah_barang_retur = document.getElementById('jumlah_retur').value;
                            // var total_harga_retur = jumlah_barang_retur * prdName[x].harga_barang;
                            // document.getElementById('total_harga_retur').value = total_harga_retur;
                        };
                        function gantiValueJumlah(){
                            var valueJumlah = $('#pilih_retur').val();
                            // console.log(valueJumlah);
                            var jumlah_barang_retur = document.getElementById('jumlah_retur').value;
                            var total_harga_retur = jumlah_barang_retur * prdName[valueJumlah].harga_barang;
                            document.getElementById('total_harga_retur').value = total_harga_retur;
                        };
                    </script>
                    <div class="form-group">
                        <label for="inputName" class="col-sm-2 control-label">Tanggal Jatuh Tempo</label>
                        <div class="col-sm-10">
                            <input type="text" name="tanggal_jatuh" class="form-controls" id="datepicker2"  placeholder="Tanggal Jatuh Tempo" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputName" class="col-sm-2 control-label">Bukti Transaksi</label>
                        <div class="col-sm-10">
                            <input type="file" class="form-controls" name="photo" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputName" class="col-sm-2 control-label">Keterangan</label>
                        <div class="col-sm-10">
                            <textarea name="keterangan" id="" cols="10" rows="5" placeholder="Keterangan Biaya Lain-lain" class="form-controls"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputName" class="col-sm-2 control-label"></label>
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-akumm">Simpan</button>
                        </div>
                    </div>
                    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
                    <script type ="text/javascript">
                        $(".autoSum").keyup(function(){
                            var jumlah_barang = parseInt($("#jumlah").val())
                            var jumlah_retur = parseInt($("#jumlah_retur").val())

                            if(jumlah_retur>jumlah_barang){
                                alert('Jumlah retur melebihi jumlah barang yang dijual.');
                            }
                        });
                    </script>
                </div>
            <?php echo form_close();?>
            </div>
        </div>
    </section>
  </div>
</div>