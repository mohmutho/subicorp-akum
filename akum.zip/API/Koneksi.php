<?php
    $host = "localhost";
    $user = "subicorp_akum";
    $pass = "Akum890*()";
    $dbname = "subicorp_akum";
    
    $conn = new mysqli($host, $user, $pass, $dbname) or die(mysqli_error());
?>