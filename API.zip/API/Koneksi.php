<?php
    $host = "localhost";
    $user = "subicorp_akum";
    $pass = "subicoakum123";
    $dbname = "subicorp_akum";
    
    $conn = new mysqli($host, $user, $pass, $dbname) or die(mysqli_error());
?>